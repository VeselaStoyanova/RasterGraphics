﻿#include <iostream>
#include "CommandsExecutor.h"

using namespace std;

int main()
{
	showMenu();
}